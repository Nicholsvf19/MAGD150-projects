let angle = 0;
let earth;
var data;
let myfont;
let displayObject = "first";
let cam;

function preload(){
  earth = loadImage("images/flattend earth image.jpg");
  data = loadJSON("data/car.json");
}

function setup() {
  createCanvas(400, 400,WEBGL);
  myfont = loadFont("fonts/OpenSans-Italic.ttf");
  cam = createCapture(VIDEO);
}

function draw() {
  //loading the JSON file
  var car = data.car[1].make
  var color = data.car[1].color
  print("my car is a: " + car + " and it's color is " + color);
  var jsonText = "my car is a : "+ car + " and it's color is "+ color;
  let p = createP(jsonText);
  p.style('font-size', '16px');
  p.position(10, 0);
  
  pointLight( 255,255,255,mouseX -200, mouseY -200,0);
  directionalLight(250, 250, 250, 0, 0, -1);
  background(175);
  rotateX(angle);
  rotateY(angle * 0.3);
  rotateZ(angle * 1.2);
  //fill(200, 0,255);
  //stroke(0);
noStroke();
  ambientMaterial(0,0,255);
  torus(100,10);
  texture(earth);
  sphere(45);
  angle += 0.03;
  translate(300,300);
  texture(cam);
  box(40);
}
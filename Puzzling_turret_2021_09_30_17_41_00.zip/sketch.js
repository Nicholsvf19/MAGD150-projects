function setup() {
  createCanvas(400, 400);
}
 
function draw() {
  background(220);
   let leftWall = 25;
  let rightWall = 75;
  let xm = mouseX;
  let xc = constrain(mouseX, leftWall, rightWall);
  stroke(150);
  line(leftWall, 0, leftWall, height);
  line(rightWall, 0, rightWall, height);
 //noStroke();
  fill(150);
  ellipse(xm, 33, 9, 9); // Not Constrained
  fill(0);
  ellipse(xc, 66, 9, 9); //constrained

  let x = 4 + 4 * 5;
print('The value of x is ' + x);
  let y = 2.15 - 5 / .4;
  print('the value of y is ' + y);
  
  line(mouseX, 0, mouseX, 400);
  line(0, mouseY, 400, mouseY);

  background(204);
  let x1 = map(mouseX, 0, width, 25, 75);
  ellipse(x1, 25, 25, 25);
  //This ellipse is constrained to the 0-100 range
  //after setting withinBounds to true
  let x2 = map(mouseX, 0, width, 0, 100, true);
  ellipse(x2, 75, 25, 25);
  
  let a = 20;
  let b = 80;
  let c = lerp(a, b, 0.2);
  let d = lerp(a, b, 0.5);
  let e = lerp(a, b, 0.8);

  strokeWeight(10);
  stroke(0); // Draw the original points in black
  point(a, y);
  point(b, y);

  stroke(100); // Draw the lerp points in gray
  point(c, y);
  point(d, y);
  point(e, y);

}


let img1;
let img2;
var pdf;
let result;
const words = [];
var marvel = 'Marvel Posters';
// initializing variables for text scrolloing
var index = 0;
let content = 'WELCOME TO THE INFINITE SCROLL '; //variable for text string
let yStart = 0; //starting position of the text wall
let customFont; //variable for custom font


function setup() {
  createCanvas(600,600);
  x = width;
  textFont(customFont); //use the custom font for text display
  textAlign(CENTER, CENTER); //adjust the anchor point of text alignment to the horizontal and vertical centers
  textSize(20);
  pdf = createPDF();
  pdf.beginRecord();
  
}

function draw() {
 background(0);
  //creating image one poster on bottom and tinting blue
  image(img1,0,0);
  tint(0,153,204);
  //added tint and filter to the photos
 filter(GRAY);
  image(img2, 0,300);
  //creating image two and putting a mask overtop
  fill('RED');
  textFont(myFont);
  textSize(36);
  // added fonts and changed the colors
  text(marvel,0,35);
  fill('YELLOW');
  textFont(myFont1);
  textSize(28);
  textAlign(LEFT);
  text('my favorite is ironman',0,70);
  print(result);
  fill('Green');
  textFont(myFont1, 16);
  textAlign(LEFT);
  for (let y = yStart; y < height; y += 28) { //use a for loop to draw the line of text multiple times down the vertical axis
    fill(255, y / 2 + 55, 100); //create a gradient by associating the fill color with the y location of the text
    text(content, width / 2, y); //display text
  }
  yStart--; //move the starting point of the loop up to create the scrolling animation, yStart-- is the same as yStart = yStart -1 or yStart-=1
    
}
function preload(){
  img1= loadImage('https://th.bing.com/th/id/R.ecc3f096a9078b93cb32c67cb6680f45?rik=TCZ5Gml5jsJDJw&riu=http%3a%2f%2fwww.pop-culture.biz%2fimages17%2f0132MABF.jpg&ehk=kyQps5o81iVTfMNqqDXN08fEZIClniBoBI2B%2bjWgntc%3d&risl=&pid=ImgRaw&r=0');
  img2=loadImage('https://th.bing.com/th/id/OIP.ZJPOL-YdweEMjnsnBr1ZFQHaKz?pid=ImgDet&rs=1');
  myFont= loadFont('fonts/OpenSans-Bold.ttf');
  myFont1= loadFont('fonts/OpenSans-SemiboldItalic.ttf');
  result = loadStrings("data/loadstrings.txt");
  //use  preload to load the custom font
  customFont = loadFont('fonts/OpenSans-SemiboldItalic.ttf');
}

function mousePressed(){
  pdf.save();
  
}

//must have video camera connected and enabled
//must allow mic and video camera
//setting up variables
var song;
let sound;
let amplitude;
let capture;
var button;
var button1;
var mic;
var sliderPan;
var sliderRate;
var video;

function preload(){
  sound = loadSound("songs/bensound-dubstep.mp3");
}

function setup() {
  let cnv=createCanvas(600,600);
  button = createButton("start");
  button1 = createButton("restart");
  sound.setVolume(0.5);
  //setting up my sliders for use
  sliderPan = createSlider(0,1.5,1,0.01);
  sliderRate = createSlider(0,1,0.5,0.01);
  //setting volume
  amplitude = new p5.Amplitude();
  button.mousePressed(togglePlay);
  button1.mousePressed(restart);
  mic = new p5.AudioIn();
  mic.start();
  capture = createCapture(VIDEO);
}

function draw() {
  background(220);
  text('Slider Rate',240,590);
  text('Slider Pan',130,590);
  let level = amplitude.getLevel();
  let size = map(level, 0,1,0,200);
  ellipse(width/2,height/2,size,size);
  sound.rate(sliderRate.value());
  sound.pan(sliderPan.value());
  fill('Red');
  ellipse(200,200,200,vol*200);
  var vol = mic.getLevel();
  text("mic volume",0,530);
  text(vol,0,550);
  if(capture.loadedmetadata){
    let c = capture.get(0,0,275,275);
    image(c,0,0);
  }
}
function restart(){
  sound.stop();
  button.html("Play");
}

function togglePlay(){
  if(sound.isPlaying()){
    sound.pause();
    //creating buttons on the HTML directly
    button.html("Play");
  }else{
    sound.loop();
    amplitude = new p5.Amplitude();
    amplitude.setInput(sound);
    button.html("pause");
  }
}

